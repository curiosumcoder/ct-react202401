export default interface ICategory
{
    categoryID: number;
    categoryName: string;
    description: string;
}
