enum AppState {
  Search,
  Create,
  Details,
  Edit  
}

export default AppState;
